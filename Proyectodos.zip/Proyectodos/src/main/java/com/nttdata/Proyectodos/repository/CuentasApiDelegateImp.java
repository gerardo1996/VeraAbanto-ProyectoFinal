package com.nttdata.Proyectodos.repository;

import com.nttdata.Proyectodos.api.CuentaApiDelegate;
import com.nttdata.Proyectodos.business.CuentasService;
import com.nttdata.Proyectodos.model.CuentaRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CuentasApiDelegateImp implements CuentaApiDelegate {

    @Autowired
    CuentasService cuentasService;


    @Override
    public ResponseEntity<List<CuentaRequest>> listarCuenta() {
        return ResponseEntity.ok(cuentasService.listarCuenta());
    }

    @Override
    public ResponseEntity<CuentaRequest> crearCuenta(CuentaRequest cuentaRequest) {
        return ResponseEntity.ok(cuentasService.crearCuenta(cuentaRequest));
    }

    @Override
    public ResponseEntity<List<CuentaRequest>> obtenerCuentasId() {
        return ResponseEntity.ok(cuentasService.obtenerCuentasId());
    }

}
