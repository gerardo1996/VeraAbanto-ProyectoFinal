package com.nttdata.Proyectodos.business;

import com.nttdata.Proyectodos.model.CuentaRequest;

import java.util.List;

public interface CuentasService {
    public List<CuentaRequest> listarCuenta();

    public CuentaRequest crearCuenta(CuentaRequest cuentaRequest) ;
    public List<CuentaRequest> obtenerCuentasId();
}
