package com.nttdata.Proyectodos;

import com.nttdata.Proyectodos.business.CuentasMapper;
import com.nttdata.Proyectodos.model.CuentaRequest;
import com.nttdata.Proyectodos.model.entity.Cuentas;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CuentaMapperTest {

    private CuentasMapper mapper = new CuentasMapper();
    @Test
    @DisplayName("TEST INGRESO DATOS")
    void testgetClienteEntity() {
        CuentaRequest request = new CuentaRequest();
        request.setNumero("4512033210");
        request.setSaldo(1500);
        request.setTipodecuenta("Ahorros");
        request.setClienteid(10);


        Cuentas result = mapper.getCuentasEntity(request);

        assertNotNull(result);
        assertEquals(request.getNumero(), result.getNumero());
        assertEquals(request.getSaldo(), result.getSaldo());
        assertEquals(request.getTipodecuenta(), result.getTipodecuenta());
        assertEquals(request.getClienteid(), result.getClienteid());
    }

    @Test
    @DisplayName("TEST LISTAR DATOS")
    void testgetClienteRequest() {

        Cuentas entity = new Cuentas();
        entity.setNumero("1120214003");
        entity.setSaldo(2000);
        entity.setTipodecuenta("Corriente");
        entity.setClienteid(4);

        CuentaRequest result = mapper.getCuentasRequest(entity);
        assertNotNull(result);
        assertEquals(entity.getNumero(), result.getNumero());
        assertEquals(entity.getSaldo(), result.getSaldo());
        assertEquals(entity.getTipodecuenta(), result.getTipodecuenta());
        assertEquals(entity.getClienteid(), result.getClienteid());
    }
}
