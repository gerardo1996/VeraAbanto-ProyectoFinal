package com.nttdata.Proyectodos;

import com.nttdata.Proyectodos.business.CuentasMapper;
import com.nttdata.Proyectodos.business.CuentasServiceImp;
import com.nttdata.Proyectodos.model.CuentaRequest;
import com.nttdata.Proyectodos.model.entity.Cuentas;
import com.nttdata.Proyectodos.repository.CuentasRepository;
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class CuentaServiceImpTest {
    @Mock
    private CuentasRepository cuentasRepository;

    @Mock
    private CuentasMapper cuentasMapper;

    @InjectMocks
    private CuentasServiceImp cuentasServiceImp;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test

    void testListar() {
        Cuentas cuenta1 = new Cuentas();
        Cuentas cuenta2 = new Cuentas();
        List<Cuentas> cuentas = Arrays.asList(cuenta1, cuenta2);

        CuentaRequest response1 = new CuentaRequest();
        CuentaRequest response2 = new CuentaRequest();

        when(cuentasRepository.findAll()).thenReturn(cuentas);
        when(cuentasMapper.getCuentasRequest(cuenta1)).thenReturn(response1);
        when(cuentasMapper.getCuentasRequest(cuenta2)).thenReturn(response2);

        List<CuentaRequest> result = cuentasServiceImp.listarCuenta();

        assertEquals(2, result.size());
        verify(cuentasRepository).findAll();
        verify(cuentasMapper, times(2)).getCuentasRequest(any());
    }
    @Test
    void crearClienteTest() {

        CuentaRequest request = new CuentaRequest();
        Cuentas entity = new Cuentas();
        CuentaRequest response = new CuentaRequest();

        when(cuentasMapper.getCuentasEntity(request)).thenReturn(entity);
        when(cuentasRepository.save(entity)).thenReturn(entity);
        when(cuentasMapper.getCuentasRequest(entity)).thenReturn(response);

        CuentaRequest result = cuentasServiceImp.crearCuenta(request);

        assertNotNull(result);
        verify(cuentasMapper).getCuentasEntity(request);
        verify(cuentasRepository).save(entity);
        verify(cuentasMapper).getCuentasRequest(entity);
    }

    @Test
    void obtenerClientesId_RetornarTipoCuenta() {
        Cuentas cuenta1 = new Cuentas();
        cuenta1.setTipodecuenta("Corriente");
        CuentaRequest cuentaRequest1 = new CuentaRequest();
        cuentaRequest1.setTipodecuenta("Corriente");

        List<Cuentas> cuentas = Arrays.asList(cuenta1);

        when(cuentasRepository.findAll()).thenReturn(cuentas);
        when(cuentasMapper.getCuentasRequest(cuenta1)).thenReturn(cuentaRequest1);
        List<CuentaRequest> resultado = cuentasServiceImp.obtenerCuentasId();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("Corriente", resultado.get(0).getTipodecuenta());
    }

}
