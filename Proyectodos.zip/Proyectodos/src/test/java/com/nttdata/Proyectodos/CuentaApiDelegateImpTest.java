package com.nttdata.Proyectodos;

import com.nttdata.Proyectodos.api.CuentaApiDelegate;
import com.nttdata.Proyectodos.business.CuentasService;
import com.nttdata.Proyectodos.model.CuentaRequest;
import com.nttdata.Proyectodos.repository.CuentasApiDelegateImp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CuentaApiDelegateImpTest {

    @Mock
    private CuentasService cuentasService;

    @InjectMocks
    private CuentasApiDelegateImp cuentasApiDelegateImp;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void listarCuentas() {

        List<CuentaRequest> cuentas = Arrays.asList(new CuentaRequest());
        when(cuentasService.listarCuenta()).thenReturn(cuentas);
        ResponseEntity<List<CuentaRequest>> resultado = cuentasApiDelegateImp.listarCuenta();
        assertEquals(200, resultado.getStatusCodeValue());
        assertNotNull(resultado.getBody());
        verify(cuentasService).listarCuenta();
    }

    @Test
    void crearCuentas() {

        CuentaRequest cuentas = new CuentaRequest();
        when(cuentasService.crearCuenta(any(CuentaRequest.class))).thenReturn(cuentas);
        ResponseEntity<CuentaRequest> resultado = cuentasApiDelegateImp.crearCuenta(cuentas);
        assertEquals(200, resultado.getStatusCodeValue());
        assertNotNull(resultado.getBody());
        verify(cuentasService).crearCuenta(any(CuentaRequest.class));
    }
}
