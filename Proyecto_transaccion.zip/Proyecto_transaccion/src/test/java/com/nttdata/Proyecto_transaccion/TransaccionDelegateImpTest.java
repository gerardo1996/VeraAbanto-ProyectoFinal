package com.nttdata.Proyecto_transaccion;

import com.nttdata.Proyecto_transaccion.bussines.TransaccionService;
import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class TransaccionDelegateImpTest {
    @Mock
    private TransaccionService transaccionService;

    @InjectMocks
    private TransaccionDelegateImp transaccionDelegate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("DEPOSITAR VALIDACION")
    void testDepositarValiacion() {
        TransaccionResponse request = new TransaccionResponse();
        request.setMonto(new BigDecimal("5800"));
        request.setCuentaOrigen("0112458962100");
        when(transaccionService.depositar(any())).thenReturn(request);

        ResponseEntity<TransaccionResponse> response = transaccionDelegate.depositar(request);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("DEPOSITO", response.getBody().getTipo());
        verify(transaccionService).depositar(request);
    }

    @Test
    @DisplayName("RETIRAR VALIDACION")
    void testRetirarValidacion() {
        TransaccionResponse request = new TransaccionResponse();
        request.setMonto(new BigDecimal("3200"));
        request.setCuentaOrigen("0112458962100");
        when(transaccionService.retirar(any())).thenReturn(request);

        ResponseEntity<TransaccionResponse> response = transaccionDelegate.retirar(request);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("RETIRO", response.getBody().getTipo());
        verify(transaccionService).retirar(request);
    }

    @Test
    @DisplayName("TRANFERENCIA VALIDACION")
    void testTransferenciaValidacion() {
        TransaccionResponse request = new TransaccionResponse();
        request.setMonto(new BigDecimal("2100"));
        request.setCuentaDestino("01124503695200");
        when(transaccionService.transferencia(any())).thenReturn(request);

        ResponseEntity<TransaccionResponse> response = transaccionDelegate.transferencia(request);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("TRANSFERENCIA", response.getBody().getTipo());
        verify(transaccionService).transferencia(request);
    }

    @Test
    @DisplayName("TEST HISTORIAL")
    void testHistorial() {
        List<TransaccionResponse> transacciones = Arrays.asList(
                new TransaccionResponse(),
                new TransaccionResponse()
        );
        when(transaccionService.hisotrial()).thenReturn(transacciones);

        // Act
        ResponseEntity<List<TransaccionResponse>> response = transaccionDelegate.hisotrial();

        // Assert
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(2, response.getBody().size());
        verify(transaccionService).hisotrial();
    }
}
