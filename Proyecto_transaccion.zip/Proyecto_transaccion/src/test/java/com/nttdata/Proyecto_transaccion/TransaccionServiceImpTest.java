package com.nttdata.Proyecto_transaccion;
import static org.junit.jupiter.api.Assertions.*;
import com.nttdata.Proyecto_transaccion.bussines.TransaccionMapper;
import com.nttdata.Proyecto_transaccion.bussines.TransaccionServiceImp;
import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import com.nttdata.Proyecto_transaccion.model.entity.Transaccion;
import com.nttdata.Proyecto_transaccion.repository.TransaccionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

import static org.mockito.Mockito.when;

public class TransaccionServiceImpTest {
    @Mock
    private TransaccionRepository transaccionRepository;

    @Mock
    private TransaccionMapper transaccionMapper;

    @InjectMocks
    private TransaccionServiceImp transaccionService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("TEST DEPOSITAR")
    void testDepositar() {
        TransaccionResponse request = new TransaccionResponse();
        Transaccion entity = new Transaccion();
        TransaccionResponse response = new TransaccionResponse();

        when(transaccionMapper.getTransaccionEntity(request)).thenReturn(entity);
        when(transaccionRepository.save(entity)).thenReturn(entity);
        when(transaccionMapper.getTransaccionResponse(entity)).thenReturn(response);

        TransaccionResponse result = transaccionService.depositar(request);

        assertNotNull(result);
        verify(transaccionMapper).getTransaccionEntity(request);
        verify(transaccionRepository).save(entity);
        verify(transaccionMapper).getTransaccionResponse(entity);
    }

    @Test
    @DisplayName("TEST RETIRAR")
    void testRetirar() {
        TransaccionResponse request = new TransaccionResponse();
        Transaccion entity = new Transaccion();
        TransaccionResponse response = new TransaccionResponse();

        when(transaccionMapper.getTransaccionEntity(request)).thenReturn(entity);
        when(transaccionRepository.save(entity)).thenReturn(entity);
        when(transaccionMapper.getTransaccionResponse(entity)).thenReturn(response);

        TransaccionResponse result = transaccionService.retirar(request);

        assertNotNull(result);
        verify(transaccionMapper).getTransaccionEntity(request);
        verify(transaccionRepository).save(entity);
        verify(transaccionMapper).getTransaccionResponse(entity);
    }

    @Test
    @DisplayName("TEST TRANSFERENCIA")
    void testTransferencia() {
        TransaccionResponse request = new TransaccionResponse();
        Transaccion entity = new Transaccion();
        TransaccionResponse response = new TransaccionResponse();

        when(transaccionMapper.getTransaccionEntity(request)).thenReturn(entity);
        when(transaccionRepository.save(entity)).thenReturn(entity);
        when(transaccionMapper.getTransaccionResponse(entity)).thenReturn(response);

        TransaccionResponse result = transaccionService.transferencia(request);

        assertNotNull(result);
        verify(transaccionMapper).getTransaccionEntity(request);
        verify(transaccionRepository).save(entity);
        verify(transaccionMapper).getTransaccionResponse(entity);
    }

    @Test
    @DisplayName("TEST TRANSACCIONES")
    void testHistorial() {
        Transaccion transaccion1 = new Transaccion();
        Transaccion transaccion2 = new Transaccion();
        List<Transaccion> transacciones = Arrays.asList(transaccion1, transaccion2);

        TransaccionResponse response1 = new TransaccionResponse();
        TransaccionResponse response2 = new TransaccionResponse();

        when(transaccionRepository.findAll()).thenReturn(transacciones);
        when(transaccionMapper.getTransaccionResponse(transaccion1)).thenReturn(response1);
        when(transaccionMapper.getTransaccionResponse(transaccion2)).thenReturn(response2);

        List<TransaccionResponse> result = transaccionService.hisotrial();

        assertEquals(2, result.size());
        verify(transaccionRepository).findAll();
        verify(transaccionMapper, times(2)).getTransaccionResponse(any());
    }

}
