package com.nttdata.Proyecto_transaccion;

import com.nttdata.Proyecto_transaccion.bussines.TransaccionMapper;
import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import com.nttdata.Proyecto_transaccion.model.entity.Transaccion;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransaccionMapperTest {

    private TransaccionMapper mapper = new TransaccionMapper();

    @Test
    @DisplayName("TEST INGRESO DATOS")
    void testGetTransaccionEntity() {
        TransaccionResponse request = new TransaccionResponse();
        request.setTipo("DEPOSITO");
        request.setMonto(new BigDecimal("500"));
        request.setFecha(LocalDateTime.now());
        request.setCuentaOrigen("123456");
        request.setCuentaDestino("789012");

        Transaccion result = mapper.getTransaccionEntity(request);

        assertNotNull(result);
        assertEquals(request.getTipo(), result.getTipo());
        assertEquals(request.getMonto(), result.getMonto());
        assertNotNull(result.getFecha());
        assertEquals(request.getCuentaOrigen(), result.getCuentaOrigen());
        assertEquals(request.getCuentaDestino(), result.getCuentaDestino());
    }
    @Test
    @DisplayName("TEST LISTAR DATOS")
    void testGetTransaccionResponse() {

        Transaccion entity = new Transaccion();
        entity.setTipo("RETIRO");
        entity.setMonto(new BigDecimal("50.00"));
        entity.setFecha(LocalDateTime.now());
        entity.setCuentaOrigen("123456");
        entity.setCuentaDestino("789012");

        TransaccionResponse result = mapper.getTransaccionResponse(entity);

        assertNotNull(result);
        assertEquals(entity.getTipo(), result.getTipo());
        assertEquals(entity.getMonto(), result.getMonto());
        assertEquals(entity.getFecha(), result.getFecha());
        assertEquals(entity.getCuentaOrigen(), result.getCuentaOrigen());
        assertEquals(entity.getCuentaDestino(), result.getCuentaDestino());
    }
}
