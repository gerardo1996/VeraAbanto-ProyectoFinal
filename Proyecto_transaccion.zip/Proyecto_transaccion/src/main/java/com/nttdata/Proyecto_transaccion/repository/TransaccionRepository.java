package com.nttdata.Proyecto_transaccion.repository;

import com.nttdata.Proyecto_transaccion.model.entity.Transaccion;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TransaccionRepository extends MongoRepository<Transaccion, String> {
}
