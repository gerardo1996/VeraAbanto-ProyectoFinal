package com.nttdata.Proyecto_transaccion.bussines;

import com.nttdata.Proyecto_transaccion.model.TransaccionResponse;
import com.nttdata.Proyecto_transaccion.repository.TransaccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransaccionServiceImp implements TransaccionService{
    @Autowired
    TransaccionRepository transaccionRepository;

    @Autowired
    TransaccionMapper transaccionMapper;


    @Override
    public List<TransaccionResponse> hisotrial() {
        return transaccionRepository.findAll().stream()
                .map(m-> transaccionMapper.getTransaccionResponse(m))
                .collect(Collectors.toList());
    }

    @Override
    public TransaccionResponse depositar(TransaccionResponse transaccionResponse) {
        return transaccionMapper.getTransaccionResponse(transaccionRepository
                .save(transaccionMapper.getTransaccionEntity(transaccionResponse)));
    }

    @Override
    public TransaccionResponse retirar(TransaccionResponse transaccionResponse) {
        return transaccionMapper.getTransaccionResponse(transaccionRepository
                .save(transaccionMapper.getTransaccionEntity(transaccionResponse)));
    }

    @Override
    public TransaccionResponse transferencia(TransaccionResponse transaccionResponse) {
        return transaccionMapper.getTransaccionResponse(transaccionRepository
                .save(transaccionMapper.getTransaccionEntity(transaccionResponse)));
    }
}
