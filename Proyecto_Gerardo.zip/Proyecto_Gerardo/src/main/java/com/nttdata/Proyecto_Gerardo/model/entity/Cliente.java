package com.nttdata.Proyecto_Gerardo.model.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Entity
@Data
@Table(name = "CLIENTES")
public class Cliente {

    @Id

    private String nombre;
    private String apellido;
    private  String dni;
    private String email;

}
