package com.nttdata.Proyecto_Gerardo.business;



import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;
import com.nttdata.Proyecto_Gerardo.model.entity.Cliente;
import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public Cliente getClienteEntity (ClienteRequest request){
        Cliente entity = new Cliente();
        entity.setNombre(request.getNombre());
        entity.setApellido(request.getApellido());
        entity.setDni(request.getDni());
        entity.setEmail(request.getEmail());
        return entity;

    }

    public ClienteRequest getClienteRequest (Cliente entity) {
        ClienteRequest request= new ClienteRequest();
        request.setNombre(entity.getNombre());
        request.setApellido(entity.getApellido());
        request.setDni(entity.getDni());
        request.setEmail(entity.getEmail());
        return request;

    }
}
