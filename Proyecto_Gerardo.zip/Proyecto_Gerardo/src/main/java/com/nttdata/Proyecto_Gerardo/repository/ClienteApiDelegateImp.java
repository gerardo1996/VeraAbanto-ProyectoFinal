package com.nttdata.Proyecto_Gerardo.repository;

import com.nttdata.Proyecto_Gerardo.api.ClienteApiDelegate;
import com.nttdata.Proyecto_Gerardo.business.ClienteService;
import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ClienteApiDelegateImp implements ClienteApiDelegate {

    @Autowired
    ClienteService clienteService;

    @Override
    public ResponseEntity<List<ClienteRequest>> listarCliente() {
        return ResponseEntity.ok(clienteService.listarCliente());
    }

    @Override
    public ResponseEntity<ClienteRequest> crearCliente(ClienteRequest clienteRequest) {
        return ResponseEntity.ok(clienteService.crearCliente(clienteRequest));
    }

    @Override
    public ResponseEntity<List<ClienteRequest>> obtenerClientesId() {
        return ResponseEntity.ok(clienteService.obtenerClientesId());
    }

    @Override
    public ResponseEntity<ClienteRequest> actualizarCliente(ClienteRequest clienteRequest) {
        return  ResponseEntity.ok(clienteService.actualizarCliente(clienteRequest));
    }





}