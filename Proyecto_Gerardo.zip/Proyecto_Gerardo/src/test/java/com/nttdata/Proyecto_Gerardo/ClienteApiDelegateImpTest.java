package com.nttdata.Proyecto_Gerardo;

import com.nttdata.Proyecto_Gerardo.business.ClienteService;
import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;
import com.nttdata.Proyecto_Gerardo.repository.ClienteApiDelegateImp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import static org.mockito.ArgumentMatchers.any;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ClienteApiDelegateImpTest {
    @Mock
    private ClienteService clienteService;

    @InjectMocks
    private ClienteApiDelegateImp clienteApiDelegate;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void listarCliente() {

        List<ClienteRequest> clientes = Arrays.asList(new ClienteRequest());
        when(clienteService.listarCliente()).thenReturn(clientes);
        ResponseEntity<List<ClienteRequest>> resultado = clienteApiDelegate.listarCliente();
        assertEquals(200, resultado.getStatusCodeValue());
        assertNotNull(resultado.getBody());
        verify(clienteService).listarCliente();
    }

    @Test
    void crearCliente() {

        ClienteRequest clienteRequest = new ClienteRequest();
        when(clienteService.crearCliente(any(ClienteRequest.class))).thenReturn(clienteRequest);
        ResponseEntity<ClienteRequest> resultado = clienteApiDelegate.crearCliente(clienteRequest);
        assertEquals(200, resultado.getStatusCodeValue());
        assertNotNull(resultado.getBody());
        verify(clienteService).crearCliente(any(ClienteRequest.class));
    }


}
