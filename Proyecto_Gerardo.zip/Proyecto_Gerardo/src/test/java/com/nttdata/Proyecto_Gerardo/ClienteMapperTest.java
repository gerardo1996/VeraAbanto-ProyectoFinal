package com.nttdata.Proyecto_Gerardo;

import com.nttdata.Proyecto_Gerardo.business.ClienteMapper;
import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;
import com.nttdata.Proyecto_Gerardo.model.entity.Cliente;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ClienteMapperTest {

    private ClienteMapper mapper = new ClienteMapper();
    @Test
    @DisplayName("TEST INGRESO DATOS")
    void testgetClienteEntity() {
        ClienteRequest request = new ClienteRequest();
        request.setNombre("Enrrique");
        request.setApellido("Carranza");
        request.setDni("75541230");
        request.setEmail("enrrique.carranza@hotmail.com");


        Cliente result = mapper.getClienteEntity(request);

        assertNotNull(result);
        assertEquals(request.getNombre(), result.getNombre());
        assertEquals(request.getApellido(), result.getApellido());
        assertEquals(request.getDni(), result.getDni());
        assertEquals(request.getEmail(), result.getEmail());
    }

    @Test
    @DisplayName("TEST LISTAR DATOS")
    void testgetClienteRequest() {

        Cliente entity = new Cliente();
        entity.setNombre("Gerardo");
        entity.setApellido("Vera");
        entity.setDni("72269644");
        entity.setEmail("gode.vera.1996@gmail.com");
        ClienteRequest result = mapper.getClienteRequest(entity);
        assertNotNull(result);
        assertEquals(entity.getNombre(), result.getNombre());
        assertEquals(entity.getApellido(), result.getApellido());
        assertEquals(entity.getDni(), result.getDni());
        assertEquals(entity.getEmail(), result.getEmail());
    }

}
