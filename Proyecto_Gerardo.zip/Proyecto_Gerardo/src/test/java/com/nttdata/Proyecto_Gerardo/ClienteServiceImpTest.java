package com.nttdata.Proyecto_Gerardo;

import com.nttdata.Proyecto_Gerardo.business.ClienteMapper;
import com.nttdata.Proyecto_Gerardo.business.ClienteServiceImp;
import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;
import com.nttdata.Proyecto_Gerardo.model.entity.Cliente;
import com.nttdata.Proyecto_Gerardo.repository.ClienteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
public class ClienteServiceImpTest {
    @Mock
    private ClienteRepository clienteRepository;

    @Mock
    private ClienteMapper clienteMapper;

    @InjectMocks
    private ClienteServiceImp clienteService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void listarClienteTest() {
        Cliente cliente = new Cliente();
        cliente.setNombre("Juan");
        cliente.setApellido("Perez");
        cliente.setDni("75123004");
        cliente.setEmail("juan.perez@gmail.com");

        ClienteRequest clienteRequest = new ClienteRequest();
        clienteRequest.setNombre("Juan");
        clienteRequest.setApellido("Perez");
        clienteRequest.setDni("75123004");
        clienteRequest.setEmail("juan.perez@gmail.com");

        List<Cliente> clientes = Arrays.asList(cliente);

        when(clienteRepository.findAll()).thenReturn(clientes);
        when(clienteMapper.getClienteRequest(any(Cliente.class))).thenReturn(clienteRequest);

        List<ClienteRequest> resultado = clienteService.listarCliente();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(clienteRepository).findAll();
        verify(clienteMapper).getClienteRequest(any(Cliente.class));
    }

    @Test
    void crearClienteTest() {

        ClienteRequest clienteRequest = new ClienteRequest();
        clienteRequest.setNombre("Daniel");
        clienteRequest.setApellido("Moncada");
        clienteRequest.setDni("70025412");
        clienteRequest.setEmail("daniel.moncada@hotmail.com.");

        Cliente cliente = new Cliente();
        cliente.setNombre("Daniel");
        cliente.setApellido("Moncada");
        cliente.setDni("70025412");
        cliente.setEmail("daniel.moncada@hotmail.com.");

        when(clienteMapper.getClienteEntity(any(ClienteRequest.class))).thenReturn(cliente);
        when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);
        when(clienteMapper.getClienteRequest(any(Cliente.class))).thenReturn(clienteRequest);

        ClienteRequest resultado = clienteService.crearCliente(clienteRequest);

        assertNotNull(resultado);
        assertEquals("Daniel", resultado.getNombre());
        verify(clienteMapper).getClienteEntity(any(ClienteRequest.class));
        verify(clienteRepository).save(any(Cliente.class));
        verify(clienteMapper).getClienteRequest(any(Cliente.class));
    }

    @Test
    void obtenerClientesId_RetornarNombreGerardo() {
        Cliente cliente1 = new Cliente();
        cliente1.setNombre("Gerardo");
        ClienteRequest clienteRequest1 = new ClienteRequest();
        clienteRequest1.setNombre("Gerardo");

        List<Cliente> clientes = Arrays.asList(cliente1);

        when(clienteRepository.findAll()).thenReturn(clientes);
        when(clienteMapper.getClienteRequest(cliente1)).thenReturn(clienteRequest1);
        List<ClienteRequest> resultado = clienteService.obtenerClientesId();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("Gerardo", resultado.get(0).getNombre());
    }

}
